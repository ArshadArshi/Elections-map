
// basically to set accrate type names we are setting them to variable and called when required

export const UserLoggedIn = 'UserLoggedIn';
export const articels = 'articels';
export const UserDetailsUpdated = 'UserDetailsUpdated';
export const loginData='loginData';