# react-shadcn-ui-template
A React equivalent template  of shadcn-ui next js template
it react-vite-tailwind-redux template 
sample website with basic login-auth and articles display 

npm i ---> install node modules


  npm run dev ---> to run the website on client side
